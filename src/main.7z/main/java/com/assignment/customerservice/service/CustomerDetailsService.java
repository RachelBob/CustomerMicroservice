package com.assignment.customerservice.service;

import com.assignment.customerservice.entity.CustomerDetails;

public interface CustomerDetailsService {
	public CustomerDetails saveCustomer(CustomerDetails customer);
	public CustomerDetails getCustomerById(Long id);
}
