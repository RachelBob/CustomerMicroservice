package com.assignment.customerservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.customerservice.entity.CustomerDetails;
import com.assignment.customerservice.exception.CustomerNotFoundException;
import com.assignment.customerservice.repository.CustomerDetailsRepository;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

	@Autowired
	CustomerDetailsRepository customerRepository;

	@Override
	public CustomerDetails saveCustomer(CustomerDetails customer) {
		CustomerDetails savedCustomer = customerRepository.save(customer);
		return savedCustomer;
	}

	@Override
	public CustomerDetails getCustomerById(Long id) {
		try {
			CustomerDetails customerById = customerRepository.getReferenceById(id);
			return customerById;
		} catch (CustomerNotFoundException exception) {
			throw new CustomerNotFoundException(exception.getMessage());
		}

	}

}
