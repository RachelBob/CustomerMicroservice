package com.assignment.customerservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.customerservice.entity.CustomerDetails;
import com.assignment.customerservice.exception.CustomerNotFoundException;
import com.assignment.customerservice.service.CustomerDetailsService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerDetailsService customerService;
	
	Logger logger=LoggerFactory.getLogger(CustomerController.class);

	@GetMapping("/test")
	public String test() {
		return "customer service";
	}
	//get username and password
	@PostMapping("/register-customer")
	public ResponseEntity<CustomerDetails> addCustomer(@RequestBody CustomerDetails customer) {
		logger.info("Request Body "+customer);
		CustomerDetails savedCustomer = customerService.saveCustomer(customer);
		return new ResponseEntity<CustomerDetails>(savedCustomer, HttpStatus.OK);
	}
	
	@GetMapping("/customers/{id}")
	public ResponseEntity<CustomerDetails> getCustomerByID(@PathVariable(value = "id") Long id) {
		logger.info("customer id is "+id);
		CustomerDetails customer=customerService.getCustomerById(id);
		if(customer == null)
			throw new CustomerNotFoundException("customer not found");
		return new ResponseEntity<CustomerDetails>(customer, HttpStatus.OK);
	}
}
